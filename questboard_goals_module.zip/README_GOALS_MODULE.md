# QuestBoard - Módulo de Metas

Este paquete añade el CRUD de metas.

## Archivos incluidos

- `app/Models/Goal.php`
- `app/Controllers/GoalController.php`
- `public/goals.php`
- `public/dashboard.php`
- `assets/css/styles.css`

## Instalación

1. Copia la carpeta `questboard` sobre tu proyecto actual.
2. Acepta sobrescribir `dashboard.php` y `styles.css`.
3. Abre:

```text
http://localhost/questboard/public/goals.php
```

## Qué permite

- Crear metas.
- Editar metas.
- Eliminar metas.
- Asociar metas a áreas de vida.
- Definir tipo, prioridad, estado, progreso y recompensas.
- Mostrar metas principales en el dashboard.
