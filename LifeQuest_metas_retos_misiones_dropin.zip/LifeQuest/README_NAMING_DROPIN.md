# LifeQuest - Nombres finales: Metas → Retos → Misiones

Este paquete ajusta la interfaz para que la estructura sea más clara para un usuario estándar.

## Estructura final visible

```text
Metas → Retos → Misiones
```

- **Metas**: lo que el usuario quiere conseguir.
- **Retos**: bloques de avance que acercan a una meta.
- **Misiones**: acciones concretas del día.

## Archivos incluidos

- `public/dashboard.php`
- `public/areas.php`
- `public/goals.php`
- `public/projects.php`
- `public/tasks.php`
- `app/Models/Task.php`
- `app/Controllers/TaskController.php`
- `assets/css/styles.css`
- `database/tasks_migration.sql`

## Instalación

1. Copia la carpeta `LifeQuest` sobre tu proyecto actual.
2. Acepta sobrescribir archivos.
3. Si todavía no tienes la tabla `tasks`, importa:

```text
LifeQuest/database/tasks_migration.sql
```

4. Prueba estas rutas:

```text
http://localhost/LifeQuest/public/goals.php      # Metas
http://localhost/LifeQuest/public/projects.php   # Retos
http://localhost/LifeQuest/public/tasks.php      # Misiones
```

## Nota técnica

El código interno mantiene nombres como `goals`, `projects` y `tasks` para no romper la base de datos ni la lógica actual. El cambio es de naming visible para el usuario.
