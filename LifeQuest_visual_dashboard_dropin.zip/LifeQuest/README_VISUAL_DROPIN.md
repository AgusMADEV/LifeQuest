# LifeQuest - Drop-in visual

Este paquete cambia la identidad visual del dashboard para acercarlo a la estética moderna gamificada que has marcado como referencia.

## Archivos incluidos

- `config/config.php`
- `public/dashboard.php`
- `assets/css/styles.css`

## Qué cambia

- Nombre visible: LifeQuest
- Sidebar tipo app gamificada
- Topbar con buscador, XP, monedas, gemas y perfil
- Dashboard visual con avatar, nivel, racha, XP, misiones y progreso
- Columna derecha con objetivo diario, próximas misiones, tienda y distribución
- Compatibilidad visual básica con las pantallas actuales de Áreas, Metas y Proyectos

## Instalación

1. Copia la carpeta `LifeQuest` sobre tu proyecto actual.
2. Acepta sobrescribir los archivos.
3. Abre:

```text
http://localhost/LifeQuest/public/dashboard.php
```

La base de datos sigue siendo `questboard` para no perder tus datos.
