<?php

declare(strict_types=1);

define('APP_NAME', 'LifeQuest');
define('APP_URL', 'http://localhost/LifeQuest/public');

define('DB_HOST', 'localhost');
define('DB_NAME', 'questboard');
define('DB_USER', 'questboard');
define('DB_PASS', '159159159');
define('DB_CHARSET', 'utf8mb4');

define('SESSION_NAME', 'lifequest_session');

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}
