# LifeQuest - Módulo de Misiones de hoy / Tareas

Este paquete añade el módulo de tareas, mostrado visualmente como **Misiones de hoy**.

## Archivos incluidos

- `app/Models/Task.php`
- `app/Controllers/TaskController.php`
- `public/tasks.php`
- `public/dashboard.php`
- `assets/css/styles.css`
- `database/tasks_migration.sql`

## Qué permite

- Crear misiones/tareas.
- Editar misiones.
- Eliminar misiones.
- Asociarlas a proyectos, objetivos y áreas.
- Definir prioridad, estado, tiempo estimado, fecha límite, XP y LifeCoins.
- Completar misiones.
- Al completar, suma XP y LifeCoins al usuario.
- Actualiza el progreso del proyecto y del objetivo relacionado.

## Instalación

1. Copia la carpeta `LifeQuest` sobre tu proyecto actual.
2. Acepta sobrescribir `dashboard.php` y `styles.css`.
3. Si tu base de datos no tiene la tabla `tasks`, importa:

```text
database/tasks_migration.sql
```

4. Abre:

```text
http://localhost/LifeQuest/public/tasks.php
```

## Siguiente paso recomendado

Después de este módulo, el siguiente bloque será **Modo Batalla**, que usará estas misiones/tareas como base.
